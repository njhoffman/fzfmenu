0=${(%):-%N}
source ${0:A:h}/zman.zsh
